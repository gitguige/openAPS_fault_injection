f = open('glucose_output_algo_bw.txt','w')
f.write(str(200))
f.close()
